from pyspark.sql import SparkSession
from pyspark.sql import functions as F

#Question1

spark = SparkSession.builder.appName("MySparkApp").getOrCreate()

#Calculate avg rating per genre
fact_ratings_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Fact_Ratings.csv", header=True, inferSchema=True)
fact_ratings_df.show(5)

dim_genre_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_Genre.csv", header=True, inferSchema=True)
dim_genre_df.show(5)

dim_genre_df.filter(F.col("genre_id").isNull() | F.col("genre_name").isNull()).count()
duplicates= (dim_genre_df.groupBy("genre_id").agg(F.count("*").alias("count")).filter("count > 1"))

dim_movie_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_Movie.csv", header=True, inferSchema=True)
dim_movie_df.show(5)

fact_ratings_df.printSchema()
dim_movie_df.printSchema()
dim_genre_df.printSchema()

from pyspark.sql.functions import avg, col
rating_by_genre_joined_df=(fact_ratings_df.join(dim_movie_df, "movie_id").join(dim_genre_df, "genre_id"))


movie_rating_avg_df=(rating_by_genre_joined_df.groupBy("movie_id", "genre_id", "title", "genre_name").agg(avg("rating_value").alias("avg_movie_rating")))
movie_rating_avg_df.show(8)

from pyspark.sql.functions import round, col
movie_rating_avg_df= movie_rating_avg_df.withColumn("avg_movie_rating", round(col("avg_movie_rating"),1))
movie_rating_avg_df.show(8)

genre_rating_avg_df= (movie_rating_avg_df.groupBy("genre_id", "genre_name").agg(avg("avg_movie_rating").alias("avg_genre_rating")).orderBy(col("avg_genre_rating").desc()))
genre_rating_avg_df.show()

from pyspark.sql.functions import col, floor
genre_rating_avg_df= genre_rating_avg_df.withColumn("avg_genre_rating", (floor(col("avg_genre_rating")*10) /10 ))
genre_rating_avg_df.show(15)

genre_rating_avg_df.select("genre_name", "avg_genre_rating").show()

#Top3 movie ratings according to genre
from pyspark.sql import Window
import pyspark.sql.functions as F
window_spec= Window.partitionBy("genre_name").orderBy(F.desc("avg_movie_rating"))
top_three_movie_rating_df = (movie_rating_avg_df.withColumn("rank",F.row_number().over(window_spec)).filter(col("rank") <= 3).orderBy(F.col("genre_id").asc()))
top_three_movie_rating_df.show(100, truncate=False)
top_three_movie_rating_df.orderBy(F.col("genre_id").asc(), F.col("rank").asc()).show(100)

#Question2

dim_device_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_Device.csv", header=True, inferSchema=True)
dim_device_df.show(8)

#For each device_type calculate how many movies were totally completed 
dim_device_df.filter(F.col("device_id").isNull() | col("device_type").isNull()).count()
duplicates= (dim_device_df.groupBy("device_id").agg(F.count("*").alias("count")).filter("count > 1"))
duplicates.show()

dim_device_df.printSchema()
device_count_completed_df= (fact_ratings_df.join(dim_device_df, "device_id"))

device_count_completed_df= (fact_ratings_df.join(dim_device_df, "device_id"))
device_count_completed_df.show()

device_completed_df= (fact_ratings_df.filter(F.col("is_completed")==1).groupBy("device_id").agg(F.count("*").alias("completed_device_count")).orderBy(F.col("device_id").asc()))
device_completed_df.show(10)

device_completed_df= (device_count_completed_df.filter(F.col("is_completed")==1).groupBy("device_id", "device_type").agg(F.count("*").alias("completed_device_count")).orderBy(F.col("device_id").asc()))
device_completed_df.show()

#Identify 2 top device where users tend to abandon movie

top_two_incomplete_device_df = (device_count_completed_df.filter(F.col("is_completed")==0).groupBy("device_id" , "device_type").agg(F.count("*").alias("abandon_movies")).orderBy(F.col("device_id").desc()))
top_two_incomplete_device_df.show(10)

top_two_incomplete_device_df = (device_count_completed_df.filter(F.col("is_completed")==0).groupBy("device_id" , "device_type").agg(F.count("*").alias("abandon_movies")).orderBy(F.col("device_id").desc()).limit(2))
top_two_incomplete_device_df.show()

#Question5

dim_user_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_User.csv",header=True, inferSchema=True)
dim_user_df.show()

#Compare avg rating given by free and premium user
ratings_user_joined_df = fact_ratings_df.join(dim_user_df, on="user_id", how="inner")
ratings_user_joined_df.show()

avg_rating_by_usertype_df= (ratings_user_joined_df.groupBy("subscription_type").agg(F.avg("rating_value").alias("avg_rating")).orderBy("subscription_type"))
avg_rating_by_usertype_df.show()

#which genres are most preffered by premium users
dim_movie_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_Movie.csv",header=True, inferSchema=True)
dim_movie_df.show()

genre_preffered_premium_user_df= ratings_user_joined_df.join(dim_movie_df, on="movie_id")
genre_preffered_premium_user_df.show()
genre_preffered_premium_user_df.orderBy(F.col("rating_value").desc()).show(50)

#Question7

#Find avg watch_duration pre genre
genre_preffered_premium_user_df= ratings_user_joined_df.join(dim_movie_df, on="movie_id")
genre_preffered_premium_user_df.show()
genre_pref_df= (genre_preffered_premium_user_df.groupBy("genre_id").agg(F.avg("duration_minutes").alias("avg_watch_duration")).orderBy(F.desc("avg_watch_duration")))
genre_pref_df.orderBy(F.col("genre_id").asc()).show(20)

# Identify genres where movies are most likely abandoned (low completion %)
device_completed_df= (genre_preffered_premium_user_df.filter(F.col("is_completed")==1).groupBy("genre_id").agg(F.count("*").alias("completed_device_count")).orderBy(F.col("genre_id").asc()))
device_completed_df.show()

genre_incomplete_df= (genre_preffered_premium_user_df.filter(F.col("is_completed")==0).groupBy("genre_id").agg(F.count("*").alias("abandon_device_count")).orderBy(F.col("genre_id").asc()))
genre_incomplete_df.show()

genre_complete_abandon_df= device_completed_df.join(genre_incomplete_df, on ="genre_id")
genre_complete_abandon_df.orderBy(F.asc("genre_id")).show()

abandon_rate_df=(genre_complete_abandon_df.withColumn("abandon_rate", F.col("abandon_device_count")/  (F.col("abandon_device_count") +  F.col("completed_device_count"))))
abandon_rate_df.orderBy(F.col("genre_id").asc()).show()

#Question 3

dim_studio_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_Studio.csv",header=True, inferSchema=True)

#List top 5 studios by avg rating
genre_preffered_premium_user_df.createOrReplaceTempView("movie_fact_ratings_view")
spark.sql("SELECT * FROM movie_fact_ratings_view LIMIT 10").show()

dim_studio_df.createOrReplaceTempView("dim_studio_temp")
spark.sql("SELECT * FROM dim_studio_temp LIMIT 10").show()

spark.sql(""" SELECT s.studio_id, s.studio_name, ROUND(AVG(f.rating_value),2) AS rating_avg FROM movie_fact_ratings_view AS f JOIN dim_studio_temp AS s ON f.studio_id = s.studio_id GROUP BY s.studio_id, s.studio_name ORDER BY rating_avg DESC LIMIT 5   """).show()
#For each studio show there most popular genre
studio_genre_df= (genre_preffered_premium_user_df.groupBy("studio_id", "genre_id").agg(F.round(F.avg("rating_value"),2).alias("avg_rating_value"), F.count("rating_value").alias("rating_count")))
window_spec = Window.partitionBy("studio_id").orderBy(F.desc("rating_count"), F.desc("avg_rating_value"))
top_genre_studio_df= (studio_genre_df.withColumn("rank", F.row_number().over(window_spec)).filter(F.col("rank")==1))
top_genre_studio_df.orderBy(F.col("studio_id").asc()).show(50)


#Question 6

dim_movie_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Dim_Movie.csv", header=True, inferSchema=True)
dim_movie_df.show(5)

fact_ratings_df= spark.read.csv("/mnt/c/Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Fact_Ratings.csv", header=True, inferSchema=True)
fact_ratings_df.show(5)

from pyspark.sql import functions as F
from pyspark.sql.window import Window

#Rank countries by total no. of ratings submitted
rating_country_df=(fact_ratings_df.join(dim_movie_df, "movie_id"))
rating_country_df.show()

rank_countries_total_ratings_df= (rating_country_df.groupBy("country").agg(F.count("rating_id").alias("total_ratings")))
window_spec= Window.orderBy(F.desc("total_ratings"))
rank_countries_total_ratings_df.show()

country_rank_df=(rank_countries_total_ratings_df.withColumn("rank", F.rank().over(window_spec)).orderBy(F.col("rank")))
country_rank_df.show()


#Country with Highest Completion rate percentage
country_completed_df= (rating_country_df.groupBy("country").agg(F.sum(F.col("is_completed")).alias("total_count"), F.count(F.col("is_completed")).alias("completed_count")))
country_completion_rate_df = (country_completed_df.withColumn("completion_percentage", F.round((F.col("total_count") / F.col("completed_count")) * 100 , 2)).orderBy(F.desc("completion_percentage")))
country_completion_rate_df.show()

#Question 8

#  Average rating per year 
rating_per_year_df_df= (rating_country_df.filter((F.col("release_year")>=2018) & (F.col("release_year")<=2025)).groupBy("release_year").agg(F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy("release_year"))
rating_per_year_df_df.show()


# Year with highest overall satisfaction (avg_rating)
rating_per_year_df_df= (rating_country_df.filter((F.col("release_year")>=2018) & (F.col("release_year")<=2025)).groupBy("release_year").agg(F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy("release_year"))
rating_per_year_df_df.show()

best_year_rating_df=(rating_per_year_df_df.orderBy(F.desc("avg_rating_value")).limit(1))
best_year_rating_df.show()

rating_per_year_df_df= (rating_country_df.filter((F.col("release_year")>=2018) & (F.col("release_year")<=2025)).groupBy("release_year").agg(F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy(F.desc("avg_rating_value")))
rating_per_year_df_df.shoindow_spec= Window.orderBy(F.col("avg_rating_value"))
window_spec= Window.orderBy(F.desc("avg_rating_value"))
rank_best_year_df= rating_per_year_df_df.withColumn("rank", F.rank().over(window_spec))
rank_best_year_df.show()

year_highest_avg_arting_df= rank_best_year_df.filter(F.col("rank")==1)
year_highest_avg_arting_df.show()


# Question 10

#movie wth highest no. of unique users rating them

movie_unique_user_df= (fact_ratings_df.groupBy("movie_id").agg(F.countDistinct("user_id").alias("unique_user_count")).orderBy(F.desc("unique_user_count")))
movie_unique_user_df.show(20)

# Identify hidden gems: movies with fewer than 100 ratings but avg rating >= 4.5.
hidden_gem_df= (fact_ratings_df.groupBy("movie_id").agg(F.count("rating_value").alias("count_rating_value"), F.round(F.avg("rating_value"),2).alias("avg_rating")).filter((F.col("count_rating_value") <100) & (F.col("avg_rating") >=4.5)).orderBy(F.desc("avg_rating")))
hidden_gem_df.show()

#Question 9

bridge_people_df= spark.read.csv("/mnt/c//Users/SrushtiRavjiPadave/Downloads/movie_platform_insights/Bridge_Movies_People.csv",header=True, inferSchema= True)
bridge_people_df.show()

# Top 10 directors by no. of movies directed
director_by_movie_df=(bridge_people_df.filter(F.col("role_type")== "Director").groupBy("person_id").agg(F.countDistinct("movie_id").alias("movie_count")).orderBy(F.desc("movie_count")).limit(10))
director_by_movie_df.show()

# Among them, which directors maintain the highest avg rating
directors_df= bridge_people_df.filter(F.col("role_type") == ("Director"))
directors_df.show()

director_avg_rating= directors_df.join(fact_ratings_df, on=("movie_id"))
director_avg_rating.show()

director_avg_rating_df=(director_avg_rating.groupBy("person_id").agg(F.countDistinct("movie_id").alias("movie_count"), F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy(F.desc("avg_rating_value")))
director_avg_rating_df.show(10)

#Question 4

# top 10 actors with the highest average ratings across their movies

actors_df= bridge_people_df.filter(F.col("role_type") == ("Actor"))
actors_df.show()

actor_avg_rating= actors_df.join(fact_ratings_df, on=("movie_id"))
actor_avg_rating.show()

actor_avg_rating_df=(actor_avg_rating.groupBy("person_id").agg(F.countDistinct("movie_id").alias("movie_count"), F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy(F.desc("avg_rating_value")).limit(10))
actor_avg_rating_df.show()

actor_avg_rating_df=(actor_avg_rating.groupBy("person_id", "role_type").agg(F.countDistinct("movie_id").alias("movie_count"), F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy(F.desc("avg_rating_value")).limit(10))
actor_avg_rating_df.show()

# Compare ratings Actors vs Directors
people_rating_joined_df= bridge_people_df.join(fact_ratings_df, on="movie_id")
people_rating_joined_df.show(5)

role_rating_compare_df= (people_rating_joined_df.groupBy("role_type").agg(F.countDistinct("movie_id").alias("movie_count"), F.count("rating_value").alias("rating_count"),F.round(F.avg("rating_value"),2).alias("avg_rating_value")).orderBy(F.desc("avg_rating_value")))
role_rating_compare_df.show()

role_rating_compare_df= (people_rating_joined_df.filter(F.col("role_type").isin("Director","Actor")).groupBy("role_type").agg(F.countDistinct("movie_id").alias("movie_count"), F.count("rating_value").alias("rating_count"),F.avg("rating_value").alias("avg_rating_value")).orderBy(F.desc("avg_rating_value")))
role_rating_compare_df.show()

